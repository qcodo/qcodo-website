This directory is for customizations and additions of the Qcodo Codegen
subtemplates.  If there are any subtemplate files in this directory which have
the same name as a subtemplate file in /includes/qcodo/codegen/subtemplates,
then the file in this directory will be used *instead* of the one there.

Remember that subtemplates are only called from within template files.

Feel free to add as you wish.
