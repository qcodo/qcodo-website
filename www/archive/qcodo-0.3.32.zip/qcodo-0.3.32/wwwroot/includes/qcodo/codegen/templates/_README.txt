This directory is for customizations and additions of the Qcodo Codegen
Templates.  If there are any template files in this directory which have the
same name as a template file in /includes/qcodo/codegen/templates, then the
file in this directory will be used *instead* of the one there.

If there are any template files in this directory in *addition* to the ones in
/includes/qcodo/codegen/templates, these additional template files will be
processed as well.

Feel free to add as you wish.  Just remember the naming structure for CodeGen
template files.

For regular class/objects:
	object*.tpl

For type classses/objects:
	type*.tpl
