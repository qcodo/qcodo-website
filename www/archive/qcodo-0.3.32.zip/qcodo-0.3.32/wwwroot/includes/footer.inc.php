<?php
	// This example footer.inc.php is intended to be modfied for your application.
?>
	</body>
</html>