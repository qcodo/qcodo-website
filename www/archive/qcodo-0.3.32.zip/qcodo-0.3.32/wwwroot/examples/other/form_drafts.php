<?php require('../../includes/prepend.inc.php'); ?>
<?php require('../includes/header.inc.php'); ?>

	<div class="instructions">
		<div class="instruction_title">Integrating QForms and the Code Generator</div>
		
		With the understanding of how the <b>Code Generator</b> can generate your data
		objects which is the heart of your <b>Model</b>, and with the examples
		of how you can use the <b>QForm</b> and <b>QControl</b> libraries to build out your
		<b>View</b> and <b>Controller</b>, you should now understand that
		the combination of both provides you a very flexible framework that
		utilizes the MVC architecture.<br/><br/>

		When you code generate your objects, Qcodo will actually provide a starting
		point for this integration in the generated <b>Form Drafts</b>.  These generated
		scripts are definitely <i>drafts</i> or starting points from which you can create
		more elaborate, useful and functional web forms for your application.<br/><br/>
		
		At a high level, this concept is very similar to the <b>scaffolding</b> which
		is provided by many other frameworks.  But note that because of the object-oriented
		approach of <b>QForms</b>, <b>Form Drafts</b> can offer much more power and
		functionality over <b>scaffolding</b>.  By having your <b>Form Draft</b> objects
		as subclasses to the generated <b>FormBase</b> objects, you can make changes
		to the design, layout, etc. to the form, and with subsequent regenerations of
		your code, you can inherit the existing changes into any new objects that
		get generated due to changes to your data model.<br/><br/>
		
		It is difficult to show this in a one-page example, so if you would like to
		see this in action, we recommend that you check out <b>Demo Part II</b>
		in the <b><a href="http://www.qcodo.com/demos/" class="bodyLink">Qcodo Demos and
		Examples</a></b>.
	</div>
	
	To view one of the generated <b>Form Drafts</b>, please click here to
	view the <b><a href="<?php _p(__VIRTUAL_DIRECTORY__ . __FORM_DRAFTS__); ?>/person_list.php"
		class="bodyLink">Person List</a></b> page.

<?php require('../includes/footer.inc.php'); ?>