<p><b>Edit Project Name</b></p>
<?php $_CONTROL->txtName->RenderWithName() ?>
<p>
	<?php $_CONTROL->btnSave->Render() ?>
	<?php $_CONTROL->btnCancel->Render() ?>
</p>