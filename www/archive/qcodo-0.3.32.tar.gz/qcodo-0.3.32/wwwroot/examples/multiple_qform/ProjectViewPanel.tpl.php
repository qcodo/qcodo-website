<?php $_CONTROL->pnlTitle->Render(); ?>
<p><?php $_CONTROL->btnEditProject->Render(); ?></p>
<?php $_CONTROL->dtgMembers->Render() ?>
