<?php
	require(__QCODO_CORE__ . '/codegen/QDatabaseCodeGen.class.php');
	require(__QCODO_CORE__ . '/codegen/QRestServiceCodeGen.class.php');
?>