<?php
	require(__QCODO_CORE__ . '/codegen/QConvertNotationBase.class.php');

	// Feel free to override any core QConvertNotationBase methods here
	abstract class QConvertNotation extends QConvertNotationBase {		
	}
?>