<?php
	require('../../../includes/prepend.inc.php');
	QImageControl::Run();
?>