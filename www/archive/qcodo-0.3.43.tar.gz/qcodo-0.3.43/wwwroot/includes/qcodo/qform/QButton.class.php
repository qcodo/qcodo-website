<?php
	class QButton extends QButtonBase {
		///////////////////////////
		// Button Preferences
		///////////////////////////

		// Feel free to specify global display preferences/defaults for all QButton controls
		protected $strCssClass = 'button';
//		protected $strFontNames = QFontFamily::Verdana;
//		protected $strFontSize = '10px';
//		protected $blnFontBold = true;
	}
?>