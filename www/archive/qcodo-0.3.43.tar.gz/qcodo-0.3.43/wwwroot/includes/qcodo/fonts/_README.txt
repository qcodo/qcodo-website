This directory is for globally-available font files (PostScript Type 1 as
.pfb and .afm pairs, or TrueType as .ttf files) for the QImageLabel
control.  See the Examples Site on QImageLabel for more information.

Feel free to add font files as needed.
