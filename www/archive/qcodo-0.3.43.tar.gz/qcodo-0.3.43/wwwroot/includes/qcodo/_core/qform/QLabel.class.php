<?php
	class QLabel extends QBlockControl {
		///////////////////////////
		// Private Member Variables
		///////////////////////////
		protected $strTagName = 'span';
		protected $blnHtmlEntities = true;
	}
?>