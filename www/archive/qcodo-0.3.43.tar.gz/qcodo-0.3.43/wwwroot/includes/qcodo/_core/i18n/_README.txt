These are Qcodo-specific (e.g. "Core") language files for
translating the form drafts and other QControls to various
languages.

PLEASE NOTE: we need contributions for other languages!

If you have additional languages, or you see languages files
that need to be fixed/updated, please post your contributions
to http://www.qcodo.com/downloads/category.php/4
