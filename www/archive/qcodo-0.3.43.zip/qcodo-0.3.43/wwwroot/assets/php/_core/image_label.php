<?php
	require('../../../includes/prepend.inc.php');
	QImageLabel::Run();
?>