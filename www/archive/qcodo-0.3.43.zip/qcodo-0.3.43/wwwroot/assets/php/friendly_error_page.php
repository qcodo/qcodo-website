<?php require(__INCLUDES__ . '/header.inc.php'); ?>

	<h3>Oops!</h3>

	<p>An error has occurred.  It has been logged and we'll look into it right away.</p>

	<p><strong>Thanks for your understanding!</strong></p>

<?php require(__INCLUDES__ . '/footer.inc.php'); ?>