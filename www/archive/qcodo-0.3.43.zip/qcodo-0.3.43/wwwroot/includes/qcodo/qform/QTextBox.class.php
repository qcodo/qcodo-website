<?php
	class QTextBox extends QTextBoxBase {
		///////////////////////////
		// TextBox Preferences
		///////////////////////////

		// Feel free to specify global display preferences/defaults for all QTextBox controls
		protected $strCssClass = 'textbox';
//		protected $strFontNames = QFontFamily::Verdana;
//		protected $strFontSize = '12px';
//		protected $strWidth = '250px';
	}
?>